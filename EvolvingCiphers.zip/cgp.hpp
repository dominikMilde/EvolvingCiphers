#pragma once 
#include <vector>

using namespace std;

/// Represents one CGP graph.
///  
/// Structure stores genotype as vector<int> and caches associated fitness.
struct Graph {
    vector<int> graph;
    double fitness;
    /// Constructor with given graph and fitness.
    Graph(vector<int> graph, double fitness);
    /// Default constructor.
    Graph();
};

/// Represents CGP entity.
/// 
/// Structure stores info about topology and CPG inputs.
struct CGP {
    int n;    ///< num of plaintexts
    int m;    ///< num of ciphertexts
    int r;    ///< num of rows
    int c;    ///< num of columns
    int a;    ///< num of node inputs
    vector<int> graph;  ///< genotype

    CGP(int n, int m, int r, int c, int a);

    /// Calculates output (cihper) for given graph based on passed inputs (plaintext).
    ///
    /// Internally uses calculateFunction().
    /// @param inputs vector<unsigned char> --> inputs in CGP graph
    /// @returns 
    unsigned char propagate(vector<unsigned char> inputs); 

    /// Calculates given operation based on passed arguments. 
    ///
    /// Corresponding functionIds: 0:AND, 1:OR, 2:NOT, 3:XOR, 4:ROR, 5:ROL
    /// @attention In nodes where one input is needed, other input is inactive - does not interact with output.
    double calculateFunction(vector<unsigned char> calcOutputs, int functionId, vector<int> nodeInputIds);
	
    /// Generates ciphertext from given plaintext and key.<summary>
    /// 
    /// @param plaintext vector of unsigned chars representing plaintext
    /// @param key vector of unsigned chars representing key
    /// @returns vector of unsigned chard representing ciphertext
    vector<unsigned char> generateCipher(vector<unsigned char> plaintext, vector <unsigned char> key);
};

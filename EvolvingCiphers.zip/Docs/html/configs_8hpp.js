var configs_8hpp =
[
    [ "generations", "configs_8hpp.html#ab58032dcd8ade6fe5b4b53a077ecb93b", null ],
    [ "generationsA", "configs_8hpp.html#ae558a4469363bccd5556f30f369877a5", null ],
    [ "keyLength", "configs_8hpp.html#a0edac48d014c76a20bc75f2cd4853e26", null ],
    [ "mutationProbability", "configs_8hpp.html#a912c3a86f13a3323a05787c0ee542840", null ],
    [ "mutationProbabilityA", "configs_8hpp.html#ae9bc225ffdaae626366b58fa2915c935", null ],
    [ "numColumns", "configs_8hpp.html#a8088a4be6d42bc1252bb2bcc25cced12", null ],
    [ "numFunctions", "configs_8hpp.html#ac2fbd3f5ff652cb75aff36f6905532f8", null ],
    [ "numInputs", "configs_8hpp.html#a6ba0c129d54afcc19dade087f32ceecd", null ],
    [ "numNodeInputs", "configs_8hpp.html#a0991aa5051bcf535f86b2efaef031887", null ],
    [ "numOutputs", "configs_8hpp.html#a536aed0f4d34b51456419990f79e32c1", null ],
    [ "numRows", "configs_8hpp.html#af3d98aa0a0b87203025173ce6baf70be", null ],
    [ "populationSize", "configs_8hpp.html#a077979fd44d63153e4aa0ac8ffec8e27", null ],
    [ "populationSizeA", "configs_8hpp.html#a59a09e6934df572ce174f7c7406f0d26", null ],
    [ "sizeLearningSet", "configs_8hpp.html#af6d9c46f9b40883394f60f28b3156844", null ],
    [ "sizeTestingSet", "configs_8hpp.html#a1bae9d58fe8a53875a651eeef2a590d2", null ],
    [ "tournamentSize", "configs_8hpp.html#ab21395138ff2e9666c6af1975e39e991", null ],
    [ "tournamentSizeA", "configs_8hpp.html#a084b3d3a38e1d9ab1c7684682e1fbf6f", null ]
];
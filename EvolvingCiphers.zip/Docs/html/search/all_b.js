var searchData=
[
  ['sizelearningset_0',['sizeLearningSet',['../configs_8hpp.html#af6d9c46f9b40883394f60f28b3156844',1,'configs.hpp']]],
  ['sizetestingset_1',['sizeTestingSet',['../configs_8hpp.html#a1bae9d58fe8a53875a651eeef2a590d2',1,'configs.hpp']]]
];

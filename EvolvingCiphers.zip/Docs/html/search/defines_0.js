var searchData=
[
  ['generations_0',['generations',['../configs_8hpp.html#ab58032dcd8ade6fe5b4b53a077ecb93b',1,'configs.hpp']]],
  ['generationsa_1',['generationsA',['../configs_8hpp.html#ae558a4469363bccd5556f30f369877a5',1,'configs.hpp']]]
];

var searchData=
[
  ['bestbob_0',['bestBob',['../evolution_8cpp.html#a16a9642fa28a14f862dcd60448a49ea3',1,'evolution.cpp']]],
  ['bestevakey_1',['bestEvaKey',['../evolution_8cpp.html#afa7a90c4ed0f150267218ceb5670fae9',1,'evolution.cpp']]]
];

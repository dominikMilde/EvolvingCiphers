var searchData=
[
  ['tournamentsize_0',['tournamentSize',['../configs_8hpp.html#ab21395138ff2e9666c6af1975e39e991',1,'configs.hpp']]],
  ['tournamentsizea_1',['tournamentSizeA',['../configs_8hpp.html#a084b3d3a38e1d9ab1c7684682e1fbf6f',1,'configs.hpp']]]
];

var searchData=
[
  ['key_0',['Key',['../class_key.html#a1ee1d88a5c4b6021be4cc4bdfd3ea648',1,'Key::Key(vector&lt; bool &gt; key, double fitness)'],['../class_key.html#a22e51dbebb18c1d33ee8bba93a1b3b4d',1,'Key::Key()']]]
];

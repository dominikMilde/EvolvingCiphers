var struct_c_g_p =
[
    [ "CGP", "struct_c_g_p.html#a52764c7bbb56c17061b9dd2c17575371", null ],
    [ "calculateFunction", "struct_c_g_p.html#abd16215b59bd48ce7f0f72004f8b3f92", null ],
    [ "generateCipher", "struct_c_g_p.html#afde5cfdf8cb9f2028d07dafa87b4a3b0", null ],
    [ "propagate", "struct_c_g_p.html#a549a57224f251235aba8d484a751d864", null ],
    [ "a", "struct_c_g_p.html#a471648e3f4d2394d7e76dbb4daac5978", null ],
    [ "c", "struct_c_g_p.html#abac9dca2d615ba3df8673e063ccedadf", null ],
    [ "graph", "struct_c_g_p.html#a51505d1bd89b8a9be66412b20ca54a89", null ],
    [ "m", "struct_c_g_p.html#aae8ff3e3b9175163aa08f7d5fd79b72f", null ],
    [ "n", "struct_c_g_p.html#a4486b35e6409530e2a4a4bec1ff6331e", null ],
    [ "r", "struct_c_g_p.html#a4ed336a9374ac95745ff01b2d0fe813a", null ]
];
var struct_graph =
[
    [ "Graph", "struct_graph.html#a6725000bc5c6849848d683543710fbf1", null ],
    [ "Graph", "struct_graph.html#ae4c72b8ac4d693c49800a4c7e273654f", null ],
    [ "fitness", "struct_graph.html#aaf03e940826eec7084f523cb9a60e9de", null ],
    [ "graph", "struct_graph.html#a9afd6b92622cabff2fa21b32aa415dbf", null ]
];
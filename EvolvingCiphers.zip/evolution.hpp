#pragma once

#include <vector>

#include "cgp.hpp"
#include "key.hpp"

/// Calculates fitness of one individual crypto algorithm on given inputs.
/// 
/// Function generates ciphertexts from passed plaintexts and than calls fitnessFunctionMultiple.
/// @param graph CPG genotype.
/// @param key key used to enc/dec.
/// @param plaintexts vector of plaintexts to encrypt.
/// @param ciphertexts vector of encrypted ciphertexts.
/// @returns fitness [0, 1].
/// 
/// @note in functions where names of the arguments are same as here, their role is same, so they won't be documented in detail.
double fitnessIndividual(vector <int>& graph, vector <unsigned char>& key, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Calculates fitness for one pair of input - output.
double fitnessFunction(vector<unsigned char>& inputs, vector<unsigned char>& outputs);

/// Find graph with the best fitness in graph population.
/// 
/// @param graphs population
/// @returns best graph
Graph findBestGraph(vector<Graph>& graphs);

/// Find key with the best fitness in key population.
/// 
/// @param key population
/// @returns best key
Key findBestKey(vector<Key>& keys);

/// Performs graph crossover between given parents and returns child.
/// 
/// @param mainGraph first parent.
/// @param otherGraph second parent.
/// @returns generated child.
vector<int> crossover(vector<int>& mainGraph, vector<int>& otherGraph);

/// Performs key crossover between given parents and returns child.
/// 
/// @param firstKey first parent.
/// @param secondKey second parent.
/// @returns generated child.
vector<bool> crossoverKey(vector<bool>& firstKey, vector<bool>& secondKey);

/// Performs two CGP crossovers (parent1 + parent2) and (parent2 + parent1) and returns the best child.
/// @param key key used to enc/dec.
/// @param plaintexts vector of plaintexts to encrypt.
/// @param ciphertexts vector of encrypted ciphertexts.
/// Internally using crossover()
/// @note in functions where names of the arguments are same as here, their role is same, so they won't be documented in detail.
Graph crossAndReturnBestOfThree(Graph& firstParent, Graph& secondParent, vector  <unsigned char>& key, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Performs two key crossovers (parent1 + parent2) and (parent2 + parent1) and returns the best child.
///
/// Internally using crossoverKey()
Key crossAndReturnBestOfThreeKey(Key& firstParent, Key& secondParent, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts, Graph& bob);

/// Performs one point mutation on given graph.
/// 
/// Other params needed to internally evaluate new generated graph.
/// @returns New Graph.
/// @warning In implementation pay attention that function genes can only be replaced by funcion genes, also, CPG topology must be taken into account.
Graph mutation(Graph& graphStruct, vector <unsigned char>& key, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Generates random CGP graph.
vector<int> randomGraph();

/// Generates random Key.
vector<bool> randomKey();

/// Fills CGP population.
/// 
/// Generates random graphs and evualuates them. (0 generation)
/// @param graphs population
void fillInitialPopulationCGP(vector<Graph>& graphs, vector <unsigned char>& key, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Prints to std::cout.
/// 
/// Debugging purposes.
void print(Graph& g);

/// Compares passed plaintext and plaintext that Bob decodes.
Graph evaluateBob(vector<vector <unsigned char>>& plaintexts, vector <unsigned char>& key, vector <vector <unsigned char>>& ciphertext);

/// Eva uses different keys and tries to 
Key evaluateEva(Graph &bob, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Fills Key population.
/// 
/// Generates random keys and evualuates them. (0 generation)
/// @param keys population
void fillInitialPopulationKeys(vector<Key>& keys, Graph& bob, vector <vector <unsigned char>>& plaintexts, vector <vector <unsigned char>>& ciphertexts);

/// Runs adverarial learning process between Bob and Eve
/// 
/// Calls evaluateBob() and evaluateEve() and calculates Alice fitness based on evolved Bob and Eve.
/// @returns Alice fitness
double rateAlice(vector<int>& alice, vector <vector <unsigned char>>& plaintexts, vector <unsigned char>& key);

/// Same except ciphertext is not passed nor needed.
/// @see crossAndReturnBestOfThree()
Graph crossAndReturnBestOfThreeAlice(Graph& firstParent, Graph& secondParent, vector<unsigned char>& key, vector<vector<unsigned char>>& plaintext);

/// Same except ciphertext is not passed not needed.
/// @see mutation().
Graph mutationAlice(Graph& alice, vector<unsigned char>& key, vector<vector<unsigned char>>& plaintexts);

/// Calculates average of more fitness function calculations.
/// 
/// Internally runs fitnessFunction() for every element in inputs and outputs vectors.
/// @returns fitness average.
double fitnessFunctionMultiple(vector <vector<unsigned char>>& inputs, vector <vector<unsigned char>>& outputs);
#pragma once

//cgp
#define numInputs 2				///<Number of inputs into CGP grid.
#define numOutputs 1			///<Number of ouputs from CGP grid.
#define numRows 1				///<Number of rows in CGP grid.
#define numColumns 12			///<Number of columns in CGP grid.
#define numNodeInputs 2			///<Number of inputs in single node.
#define numFunctions 6			///<Number of functions nodes can execute.

//evolutionBobAndEve
#define generations 200			///<Max number of generations for Bob (B) and Eve (E) evolution. 
#define populationSize 15		///<Population size for B and E entities.
#define tournamentSize 10		///<Tournament size for B and E entities.
#define mutationProbability 0.5	///<Mutation probability for B and E entites.

//evolutionAlice
#define generationsA 100			///<Max number of generations for Alice (A) evolution. 
#define populationSizeA 25			///<Population size for A entities.
#define tournamentSizeA 10			///<Tournament size for A entities.
#define mutationProbabilityA 0.5	///<Mutation probability for A entites.

//key
#define keyLength 24				///<Key length in Bytes.

//number of plaintexts and key
#define sizeLearningSet 50			///<Number of plaintexts and keys in learning set. 
#define sizeTestingSet 50			///<Number of plaintexts and keys in test set. 

#pragma once 
#include <vector>

#include "configs.hpp"

using namespace std;

/// Represents one cryptographic key.
///  
/// Structure stores key as vector<bool> and caches associated fitness.
class Key {
public:
	vector<bool> key;
    double fitness;

    ///Constructor with given key and fitness.
    Key(vector<bool> key, double fitness);  
    ///Default constructor.
    Key();                                  

    /// Converts key from vector<bool> to vector <unsigned char>.
    /// 
    /// In order to achieve complieace with CPG inputs.
    /// @returns key as vector of unsigned chars.
    vector <unsigned char> toChar();

    /// Prints key in binary form.
    /// 
    /// Prints to std::cout, mostly debugging purposes.
    void printKey();
};

